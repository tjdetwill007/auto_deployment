import boto3
from botocore.exceptions import ClientError
import json
def lambda_handler(event, context):
    """Generates the presigned URL to allow users to upload their source code directly into the bucket"""
    
    body=event["body"]
    body=json.loads(body)
    filename=body["message"]
    print(filename)
    try:
        client = boto3.client('s3')
        response = client.generate_presigned_url(ClientMethod='put_object', Params={'Bucket': 'language-source-code', 'Key': filename, 'ContentType':"application/x-zip-compressed"}, ExpiresIn=3600)
        print(response)
        return {"statusCode":200,"body":response}
    except ClientError as e:
        print(e)
        return {"statusCode":500,"body":"Error generating presigned url"}